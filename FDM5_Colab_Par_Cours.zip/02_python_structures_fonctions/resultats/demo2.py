def affiche_b():
    "Affiche b."
    print('b')

def affiche_a():
    "Affiche a."
    print('a')

# affiche_b() est exécuté à l'importation :
affiche_b()

if __name__ == '__main__':
    # affiche_a() n'est exécuté que si le module est lancé directement :
    affiche_a()
