"Un module de démonstration."

c = 2
d = 4

def affiche_a():
    "Affiche a."
    print('a')

def affiche_b():
    "Affiche b."
    print('b')
