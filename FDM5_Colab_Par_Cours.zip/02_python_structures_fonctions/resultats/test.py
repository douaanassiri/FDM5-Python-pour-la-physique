message = "Bonjour\ncomment\nallez-vous ?"
for mot in message.split("\n"):
    print(mot)
